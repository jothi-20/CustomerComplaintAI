import { Link } from 'react-router-dom';

const headerStyle: React.CSSProperties = {
  backgroundColor: '#004085',
  padding: '15px 30px',
  color: 'white',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  borderBottom: '2px solid #003066'
};

const logoContainerStyle: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: '12px',
  fontSize: '1.6rem',
  fontWeight: 'bold',
  textDecoration: 'none',
  color: 'white'
};

const navStyle: React.CSSProperties = {
  display: 'flex',
  gap: '25px',
};

const linkStyle: React.CSSProperties = {
  color: 'white',
  textDecoration: 'none',
  fontSize: '1.1rem',
  padding: '5px 10px',
  borderRadius: '4px',
};

export default function Header() {
  return (
    <header style={headerStyle}>
      <Link to="/" style={logoContainerStyle}>
        {/* Bank Icon SVG */}
        <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <rect x="3" y="11" width="18" height="10" rx="2" ry="2"></rect>
            <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
        </svg>
        <span>RelAI Bank</span>
      </Link>
      <nav style={navStyle}>
        <Link to="/" style={linkStyle}>Dashboard</Link>
        <Link to="/create" style={linkStyle}>Create Case</Link>
        <Link to="/register" style={linkStyle}>Case Register</Link>
      </nav>
    </header>
  );
}