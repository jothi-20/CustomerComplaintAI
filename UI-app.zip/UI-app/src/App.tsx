import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Dashboard from './pages/Dashboard'
import CaseForm from './pages/CaseForm'
import CaseRegister from './pages/CaseRegister'
import AuditView from './pages/AuditView'
import EditCase from './pages/EditCase'
import Header from './Header'

export default function App() {
  return (
    <BrowserRouter>
      <Header />
      <Routes>
        <Route path="/" element={<Dashboard/>} />
        <Route path="/create" element={<CaseForm/>} />
        <Route path="/edit/:id" element={<EditCase/>} />
        <Route path="/register" element={<CaseRegister/>} />
        <Route path="/audit/:id" element={<AuditView/>} />
      </Routes>
    </BrowserRouter>
  )
}