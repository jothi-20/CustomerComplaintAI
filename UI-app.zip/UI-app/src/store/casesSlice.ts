import { createSlice, PayloadAction } from '@reduxjs/toolkit'

export interface Case {
  id: string
  customerRef: string
  type: string
  channel: string
  priority: string
  rawNotes: string
  aiNote: string
  finalNote: string
  status: string
  createdAt: string
}

const initialState: Case[] = []

const casesSlice = createSlice({
  name: 'cases',
  initialState,
  reducers: {
    addCase: (state, action: PayloadAction<Case>) => {
      state.push(action.payload)
    },
    updateCase: (state, action: PayloadAction<Case>) => {
      const idx = state.findIndex(c => c.id === action.payload.id)
      if (idx !== -1) state[idx] = action.payload
    }
  }
})

export const { addCase, updateCase } = casesSlice.actions
export default casesSlice.reducer