import React from 'react'
import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import { Provider } from 'react-redux'
import { MemoryRouter, Route, Routes } from 'react-router-dom'
import CaseForm from './CaseForm'
import { store } from '../store/store'
import * as reactRedux from 'react-redux'

// Mock useNavigate
const mockNavigate = jest.fn()
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockNavigate,
}))

describe('CaseForm Component', () => {
  beforeEach(() => {
    jest.clearAllMocks()
    global.fetch = jest.fn()
  })

  it('renders create form correctly', () => {
    render(
      <Provider store={store}>
        <MemoryRouter>
          <CaseForm />
        </MemoryRouter>
      </Provider>
    )

    expect(screen.getByText('Create New Case')).toBeInTheDocument()
    expect(screen.getByText('Customer Reference ID')).toBeInTheDocument()
  })

  it('handles input changes', () => {
    render(
      <Provider store={store}>
        <MemoryRouter>
          <CaseForm />
        </MemoryRouter>
      </Provider>
    )

    const input = screen.getByPlaceholderText('e.g. CUST-12345')
    fireEvent.change(input, { target: { value: 'TEST-REF' } })
    expect(input).toHaveValue('TEST-REF')
  })

  it('shows error when fields are empty on save', () => {
    render(
      <Provider store={store}>
        <MemoryRouter>
          <CaseForm />
        </MemoryRouter>
      </Provider>
    )

    fireEvent.click(screen.getByText('Generate & Save'))
    expect(screen.getByText('Please fill in Customer Reference ID and Raw Notes.')).toBeInTheDocument()
  })

  it('submits new case successfully', async () => {
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: async () => ({ id: 123, status: 'Draft' }),
    })

    const useDispatchSpy = jest.spyOn(reactRedux, 'useDispatch')
    const mockDispatch = jest.fn()
    useDispatchSpy.mockReturnValue(mockDispatch)

    render(
      <Provider store={store}>
        <MemoryRouter>
          <CaseForm />
        </MemoryRouter>
      </Provider>
    )

    fireEvent.change(screen.getByPlaceholderText('e.g. CUST-12345'), { target: { value: 'CUST-1' } })
    fireEvent.change(screen.getByPlaceholderText('Enter detailed case notes here...'), { target: { value: 'Some notes' } })
    
    fireEvent.click(screen.getByText('Generate & Save'))

    await waitFor(() => {
        expect(global.fetch).toHaveBeenCalled()
        expect(mockDispatch).toHaveBeenCalled()
        expect(mockNavigate).toHaveBeenCalledWith('/register')
    })
  })

  it('loads existing case for editing', () => {
    const mockCase = { id: '123', customerRef: 'EXISTING', type: 'Inquiry', channel: 'Call', priority: 'Medium', rawNotes: 'Old notes' }
    jest.spyOn(reactRedux, 'useSelector').mockReturnValue(mockCase)

    render(
      <Provider store={store}>
        <MemoryRouter initialEntries={['/edit/123']}>
            <Routes>
                <Route path="/edit/:id" element={<CaseForm />} />
            </Routes>
        </MemoryRouter>
      </Provider>
    )

    expect(screen.getByDisplayValue('EXISTING')).toBeInTheDocument()
    expect(screen.getByText('Edit Case')).toBeInTheDocument()
  })
})