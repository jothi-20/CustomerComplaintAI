import { useSelector } from 'react-redux'
import { RootState } from '../store/store'
import { Link } from 'react-router-dom'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'

export default function Dashboard() {
  const cases = useSelector((s: RootState) => s.cases)

  // Metrics
  const totalCases = cases.length
  const draftCases = cases.filter(c => c.status === 'Draft').length
  const reviewedCases = cases.filter(c => c.status === 'Reviewed').length
  const finalizedCases = cases.filter(c => c.status === 'Finalized').length

  // SLA Breach Calculation
  const slaBreachedCases = cases.filter(c => {
    if (c.status === 'Finalized') return false
    let slaDate
    if (c.slaDate) {
      slaDate = new Date(c.slaDate)
    } else {
      const d = new Date(c.createdAt)
      const hours = c.priority === 'High' ? 24 : c.priority === 'Low' ? 72 : 48
      d.setHours(d.getHours() + hours)
      slaDate = d
    }
    return new Date() > slaDate
  }).length

  // Priority Distribution
  const highPriority = cases.filter(c => c.priority === 'High').length
  const mediumPriority = cases.filter(c => c.priority === 'Medium').length
  const lowPriority = cases.filter(c => c.priority === 'Low').length

  const priorityData = [
    { name: 'High', value: highPriority },
    { name: 'Medium', value: mediumPriority },
    { name: 'Low', value: lowPriority },
    { name: 'SLA Breached', value: slaBreachedCases },
  ]
  const PRIORITY_COLORS = ['#dc3545', '#ffc107', '#28a745', '#b02a37']

  const metricsData = [
    { name: 'Total', value: totalCases, color: '#007bff' },
    { name: 'Draft', value: draftCases, color: '#ffc107' },
    { name: 'Reviewed', value: reviewedCases, color: '#17a2b8' },
    { name: 'Finalized', value: finalizedCases, color: '#28a745' },
  ]

  // Channel Distribution
  const channels = cases.reduce((acc, curr) => {
    acc[curr.channel] = (acc[curr.channel] || 0) + 1
    return acc
  }, {} as Record<string, number>)

  const channelData = Object.entries(channels).map(([name, value]) => ({ name, value }))
  const CHANNEL_COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042']

  const handleExport = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(cases, null, 2));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", "cases_export.json");
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  }

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      {/* <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <h2 style={{ margin: 0 }}>Overall Complaints Dashboard</h2>
        <button onClick={handleExport} style={{ padding: '8px 16px', backgroundColor: '#28a745', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>
          Export Data
        </button>
      </div> */}

      {/* Key Metrics Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '20px', marginBottom: '30px' }}>
        <Card title="Total Cases" value={totalCases} color="#007bff" />
        <Card title="Draft" value={draftCases} color="#ffc107" />
        <Card title="Reviewed" value={reviewedCases} color="#17a2b8" />
        <Card title="Finalized" value={finalizedCases} color="#28a745" />
        <Card title="SLA Breached" value={slaBreachedCases} color="#dc3545" />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '30px' }}>
        {/* Bar Chart for Key Metrics */}
        <div style={{ height: '350px', border: '1px solid #ddd', padding: '15px', borderRadius: '8px' }}>
          <h3>Priority & SLA Overview</h3>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={priorityData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="value">
                {priorityData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={PRIORITY_COLORS[index % PRIORITY_COLORS.length]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Priority Distribution */}
        <div style={{ border: '1px solid #ddd', padding: '15px', borderRadius: '8px', height: '350px' }}>
          <h3>Channel Distribution</h3>
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={channelData} cx="50%" cy="50%" innerRadius={60} outerRadius={80} fill="#8884d8" paddingAngle={5} dataKey="value">
                {channelData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={CHANNEL_COLORS[index % CHANNEL_COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent Activity / Drill Down */}
      <div style={{ border: '1px solid #ddd', padding: '15px', borderRadius: '8px' }}>
        <h3>Recent Cases (Drill-down)</h3>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ borderBottom: '2px solid #eee', textAlign: 'left' }}>
              <th style={{ padding: '10px' }}>ID</th>
              <th style={{ padding: '10px' }}>Customer</th>
              <th style={{ padding: '10px' }}>Sentiment</th>
              <th style={{ padding: '10px' }}>AI Tags</th>
              <th style={{ padding: '10px' }}>Status</th>
              <th style={{ padding: '10px' }}>Priority</th>
              <th style={{ padding: '10px' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {cases.slice(-5).reverse().map(c => (
              <tr key={c.id} style={{ borderBottom: '1px solid #eee' }}>
                <td style={{ padding: '10px' }}>{c.id}</td>
                <td style={{ padding: '10px' }}>{c.customerRef}</td>
                <td style={{ padding: '10px' }}>{c.customerSentiment}</td>
                <td style={{ padding: '10px' }}>{Array.isArray(c.aiGeneratedTags) ? c.aiGeneratedTags.join(', ') : c.aiGeneratedTags}</td>
                <td style={{ padding: '10px' }}>{c.status}</td>
                <td style={{ padding: '10px' }}>{c.priority}</td>
                <td style={{ padding: '10px' }}>
                  <Link to={`/audit/${c.id}`} style={{ color: '#007bff', textDecoration: 'none', marginRight: '10px' }}>Audit View</Link>
                </td>
              </tr>
            ))}
            {cases.length === 0 && <tr><td colSpan={7} style={{ padding: '10px', textAlign: 'center' }}>No cases found</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  )
}

function Card({ title, value, color }: { title: string, value: number, color: string }) {
  return (
    <div style={{ backgroundColor: color, color: 'white', padding: '20px', borderRadius: '8px', textAlign: 'center' }}>
      <h3 style={{ margin: '0 0 10px 0', fontSize: '1.2rem' }}>{title}</h3>
      <p style={{ margin: 0, fontSize: '2rem', fontWeight: 'bold' }}>{value}</p>
    </div>
  )
}