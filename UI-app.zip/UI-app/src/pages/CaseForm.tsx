import { useDispatch, useSelector } from 'react-redux'
import { addCase, updateCase } from '../store/casesSlice'
import { useState, useEffect, useRef } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { RootState } from '../store/store'

export default function CaseForm(){
  const dispatch = useDispatch()
  const nav = useNavigate()
  const { id } = useParams()
  const existingCase = useSelector((state: RootState) => state.cases.find(c => c.id === id))
  
  const [customerRef, setCustomerRef] = useState('')
  const [interactionType, setInteractionType] = useState('Inquiry')
  const [channel, setChannel] = useState('Call')
  const [priority, setPriority] = useState('Medium')
  const [rawNotes, setRawNotes] = useState('')
  const [error, setError] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [suggestionData, setSuggestionData] = useState<any>(null)
  const [loadingSuggestions, setLoadingSuggestions] = useState(false)
  const abortControllerRef = useRef<AbortController | null>(null)

  useEffect(() => {
    if (existingCase) {
      setCustomerRef(existingCase.customerRef)
      setInteractionType(existingCase.type)
      setChannel(existingCase.channel)
      setPriority(existingCase.priority)
      setRawNotes(existingCase.rawNotes)
    }
  }, [existingCase])

  const generateAI = () => {
    return `Interaction Summary: Customer contacted via ${channel} regarding ${interactionType}.\nPriority: ${priority}\nAction Taken: Case recorded.\nNext Steps: Follow-up required.`
  }

  const getSLAHours = (p: string) => {
    if (p === 'High') return 24
    if (p === 'Medium') return 48
    return 72 // Low
  }

  const generateCaseId = () => {
    return Math.floor(1000000000 + Math.random() * 9000000000).toString()
  }

  const handleGenerate = async () => {
    if (!customerRef.trim() || !rawNotes.trim()) {
      setError('Please fill in Customer Reference ID and Raw Notes.')
      return
    }

    if (abortControllerRef.current) {
      abortControllerRef.current.abort()
    }

    setShowModal(true)
    setLoadingSuggestions(true)
    setError('')
    setSuggestionData(null)

    const controller = new AbortController()
    abortControllerRef.current = controller

    try {
      const payload = {
        "customer-id": customerRef,
        "Priority": priority,
        "Interaction Type": interactionType,
        "Notes": rawNotes
      }

      const response = await fetch('http://127.0.0.1:8000/suggestions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        signal: controller.signal
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.detail || 'Failed to fetch suggestions')
      }
      const data = await response.json()
      setSuggestionData(data)
    } catch (e: any) {
      if (e.name !== 'AbortError') {
        setError('Error fetching suggestions: ' + e.message)
      }
    } finally {
      if (abortControllerRef.current === controller) {
        setLoadingSuggestions(false)
        abortControllerRef.current = null
      }
    }
  }

  const confirmSave = async () => {
    if (existingCase) {
      const updatedTimeline = [
        ...(existingCase.timeline || []),
        { 
          time: new Date().toLocaleString(), 
          title: 'Case Updated', 
          detail: `Updated via Form | Priority: ${priority}` 
        }
      ]
      dispatch(updateCase({
        ...existingCase,
        customerRef,
        type: interactionType,
        channel,
        priority,
        rawNotes,
        aiNote: generateAI(),
        finalNote: generateAI(),
        timeline: updatedTimeline
      }))
      nav('/register')
    } else {
      try {
        const payload = {
          "customer-id": customerRef,
          "Priority": priority,
          "Interaction Type": interactionType,
          "Notes": rawNotes
        }

        const response = await fetch('http://127.0.0.1:8000/complaints/', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        })

        if (!response.ok) {
          const errorData = await response.json()
          throw new Error(errorData.detail || 'Failed to create ticket')
        }

        const data = await response.json()
        
        const slaDate = new Date()
        slaDate.setHours(slaDate.getHours() + getSLAHours(priority))

        dispatch(addCase({
          id: data.id ? String(data.id) : generateCaseId(),
          customerRef: data.customer_ref || customerRef,
          type: data.type || interactionType,
          channel: data.channel || channel,
          priority: data.priority || priority,
          rawNotes: data.raw_notes || rawNotes,
          aiNote: data.ai_note || generateAI(),
          finalNote: data.final_note || generateAI(),
          status: data.status || 'Draft',
          createdAt: data.created_at || new Date().toISOString(),
          slaDate: data.sla_date || slaDate.toISOString(),
          customerSentiment: data.customer_sentiment,
          aiGeneratedTags: data.ai_generated_tags,
          timeline: data.timeline || [
            { time: new Date().toLocaleString(), title: 'Case Created', detail: `Created via ${channel} | Priority: ${priority}` },
            { time: new Date().toLocaleString(), title: 'AI Processing', detail: 'AI generated initial summary and notes' }
          ]
        }))
        nav('/register')
      } catch (e: any) {
        setError('Error creating case: ' + e.message)
      }
    }
  }

  // Styles
  const containerStyle: React.CSSProperties = {
    maxWidth: '800px',
    margin: '40px auto',
    padding: '40px',
    backgroundColor: '#ffffff',
    borderRadius: '12px',
    boxShadow: '0 10px 25px rgba(0,0,0,0.05)',
    fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"
  };

  const headerStyle: React.CSSProperties = {
    backgroundColor: '#0056b3',
    color: 'white',
    padding: '25px 40px',
    margin: '-40px -40px 30px -40px',
    borderTopLeftRadius: '12px',
    borderTopRightRadius: '12px',
    fontSize: '1.5rem',
    fontWeight: 'bold',
    marginBottom: '30px',
  };

  const rowStyle: React.CSSProperties = {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: '20px',
    marginBottom: '20px'
  };

  const labelStyle: React.CSSProperties = {
    display: 'block',
    marginBottom: '8px',
    fontWeight: 600,
    color: '#4a5568',
    fontSize: '0.95rem'
  };

  const inputStyle: React.CSSProperties = {
    width: '100%',
    padding: '12px',
    borderRadius: '8px',
    border: '1px solid #e2e8f0',
    fontSize: '1rem',
    transition: 'border-color 0.2s',
    boxSizing: 'border-box'
  };

  const buttonContainerStyle: React.CSSProperties = {
    display: 'flex',
    justifyContent: 'flex-end',
    gap: '15px',
    marginTop: '30px'
  };

  const primaryButtonStyle: React.CSSProperties = {
    padding: '12px 24px',
    backgroundColor: '#0056b3',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    fontSize: '1rem',
    fontWeight: 600,
    cursor: 'pointer',
    boxShadow: '0 2px 4px rgba(0, 86, 179, 0.2)'
  };

  const secondaryButtonStyle: React.CSSProperties = {
    padding: '12px 24px',
    backgroundColor: '#edf2f7',
    color: '#4a5568',
    border: 'none',
    borderRadius: '6px',
    fontSize: '1rem',
    fontWeight: 600,
    cursor: 'pointer'
  };

  const modalOverlayStyle: React.CSSProperties = {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.5)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000
  };

  const modalContentStyle: React.CSSProperties = {
    backgroundColor: 'white',
    padding: '20px',
    borderRadius: '8px',
    width: '500px',
    maxWidth: '90%'
  };

  return (
    <div style={{ backgroundColor: '#f8fafc', minHeight: '100vh', padding: '20px' }}>
      <div style={containerStyle}>
        <h2 style={headerStyle}>{id ? 'Edit Case' : 'Create New Case'}</h2>
        {error && <div style={{ color: '#721c24', backgroundColor: '#f8d7da', padding: '10px', borderRadius: '5px', marginBottom: '20px', border: '1px solid #f5c6cb' }}>{error}</div>}
        
        <div style={rowStyle}>
          <div>
            <label style={labelStyle}>Customer ID</label>
            <input 
              type="text" 
              value={customerRef} 
              onChange={e => setCustomerRef(e.target.value)} 
              style={inputStyle} 
              placeholder="e.g. CUST-12345" 
            />
          </div>
          <div>
            <label style={labelStyle}>Priority</label>
            <select value={priority} onChange={e => setPriority(e.target.value)} style={inputStyle}>
              <option value="Low">Low</option>
              <option value="Medium">Medium</option>
              <option value="High">High</option>
            </select>
          </div>
        </div>

        <div style={rowStyle}>
          <div>
            <label style={labelStyle}>Interaction Type</label>
            <select value={interactionType} onChange={e => setInteractionType(e.target.value)} style={inputStyle}>
              <option value="Inquiry">Inquiry</option>
              <option value="Complaint">Complaint</option>
              <option value="Service Request">Service Request</option>
              <option value="Follow-up">Follow-up</option>
            </select>
          </div>
          {/* <div>
            <label style={labelStyle}>Channel</label>
            <select value={channel} onChange={e => setChannel(e.target.value)} style={inputStyle}>
              <option value="Call">Call</option>
              <option value="Email">Email</option>
              <option value="Branch">Branch</option>
              <option value="Chat">Chat</option>
            </select>
          </div> */}
        </div>

        <div style={{ marginBottom: '20px' }}>
          <label style={labelStyle}>Raw Notes</label>
          <textarea 
            rows={8} 
            value={rawNotes} 
            onChange={e => setRawNotes(e.target.value)} 
            style={{ ...inputStyle, resize: 'vertical', minHeight: '120px' }} 
            placeholder="Enter detailed case notes here..." 
          />
        </div>

        <div style={buttonContainerStyle}>
          <button onClick={() => nav('/')} style={secondaryButtonStyle}>Cancel</button>
          <button onClick={handleGenerate} style={primaryButtonStyle}>Generate</button>
        </div>

        {showModal && (
          <div style={modalOverlayStyle}>
            <div style={modalContentStyle}>
              <h3>AI Suggestions</h3>
              {loadingSuggestions ? (
                <p>Loading suggestions...</p>
              ) : (
                <div>
                  {error ? (
                    <div style={{ color: '#721c24', backgroundColor: '#f8d7da', padding: '10px', borderRadius: '4px', marginBottom: '10px' }}>
                      {error}
                    </div>
                  ) : suggestionData ? (
                    <div style={{ backgroundColor: '#f4f4f4', padding: '15px', borderRadius: '4px', maxHeight: '400px', overflowY: 'auto' }}>
                      {suggestionData.suggested_response && <p style={{ marginBottom: '10px' }}>{suggestionData.suggested_response}</p>}
                      {suggestionData.suggested_actions && Array.isArray(suggestionData.suggested_actions) && (
                        <ul style={{ paddingLeft: '20px', margin: 0 }}>
                          {suggestionData.suggested_actions.map((action: string, i: number) => (
                            <li key={i} style={{ marginBottom: '5px' }}>{action}</li>
                          ))}
                        </ul>
                      )}
                      {!suggestionData.suggested_response && !suggestionData.suggested_actions && (
                        <div style={{ whiteSpace: 'pre-wrap' }}>
                          {suggestionData.detail || JSON.stringify(suggestionData, null, 2)}
                        </div>
                      )}
                    </div>
                  ) : <p>No suggestions available.</p>}
                  <div style={{ marginTop: '20px', display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
                    <button onClick={() => {
                      if (abortControllerRef.current) {
                        abortControllerRef.current.abort()
                      }
                      setShowModal(false)
                    }} style={secondaryButtonStyle}>Dismiss</button>
                    <button onClick={confirmSave} style={{
                      ...primaryButtonStyle,
                      opacity: (!!error || !suggestionData) ? 0.5 : 1,
                      cursor: (!!error || !suggestionData) ? 'not-allowed' : 'pointer'
                    }} disabled={!!error || !suggestionData}>Create</button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}