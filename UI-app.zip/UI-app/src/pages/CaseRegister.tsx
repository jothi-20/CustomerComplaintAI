import { useState } from 'react'
import { useSelector } from 'react-redux'
import { RootState } from '../store/store'
import { Link } from 'react-router-dom'

export default function CaseRegister() {
  const cases = useSelector((s: RootState) => s.cases)

  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [priorityFilter, setPriorityFilter] = useState('')
  const [channelFilter, setChannelFilter] = useState('')
  const [slaBreachOnly, setSlaBreachOnly] = useState(false)

  // SLA Logic: Use stored date or calculate based on priority
  const getSlaDate = (c: any) => {
    if (c.slaDate) return new Date(c.slaDate)
    const d = new Date(c.createdAt)
    const hours = c.priority === 'High' ? 24 : c.priority === 'Low' ? 72 : 48
    d.setHours(d.getHours() + hours)
    return d
  }

  const isBreached = (c: any) => {
    if (c.status === 'Finalized') return false
    return new Date() > getSlaDate(c)
  }

  const filteredCases = cases.filter(c => {
    const matchesSearch = c.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.customerRef.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter ? c.status === statusFilter : true
    const matchesPriority = priorityFilter ? c.priority === priorityFilter : true
    const matchesChannel = channelFilter ? c.channel === channelFilter : true
    const matchesSla = slaBreachOnly ? isBreached(c) : true

    return matchesSearch && matchesStatus && matchesPriority && matchesChannel && matchesSla
  })

  // Styles
  const containerStyle: React.CSSProperties = {
    padding: '20px',
    backgroundColor: '#f8fafc',
    minHeight: '100vh',
    fontFamily: "'Segoe UI', sans-serif"
  }

  const headerStyle: React.CSSProperties = {
    marginBottom: '20px',
    color: '#1e293b'
  }

  const filterBarStyle: React.CSSProperties = {
    display: 'flex',
    gap: '15px',
    marginBottom: '20px',
    flexWrap: 'wrap',
    backgroundColor: 'white',
    padding: '20px',
    borderRadius: '8px',
    boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
    alignItems: 'center'
  }

  const inputStyle: React.CSSProperties = {
    padding: '10px 12px',
    borderRadius: '6px',
    border: '1px solid #e2e8f0',
    minWidth: '200px'
  }

  const selectStyle: React.CSSProperties = {
    padding: '10px 12px',
    borderRadius: '6px',
    border: '1px solid #e2e8f0',
    minWidth: '150px'
  }

  const tableContainerStyle: React.CSSProperties = {
    backgroundColor: 'white',
    borderRadius: '8px',
    boxShadow: '0 4px 6px rgba(0,0,0,0.05)',
    overflow: 'hidden'
  }

  const tableStyle: React.CSSProperties = {
    width: '100%',
    borderCollapse: 'collapse',
    textAlign: 'left'
  }

  const thStyle: React.CSSProperties = {
    backgroundColor: '#f1f5f9',
    padding: '15px',
    fontWeight: 600,
    color: '#475569',
    borderBottom: '1px solid #e2e8f0',
    fontSize: '0.9rem',
    textTransform: 'uppercase',
    letterSpacing: '0.05em'
  }

  const tdStyle: React.CSSProperties = {
    padding: '15px',
    borderBottom: '1px solid #e2e8f0',
    color: '#334155',
    fontSize: '0.95rem'
  }

  const getPriorityColor = (p: string) => {
    switch (p) {
      case 'High': return '#ef4444';
      case 'Medium': return '#f59e0b';
      case 'Low': return '#10b981';
      default: return '#64748b';
    }
  }

  const getStatusBadgeStyle = (s: string): React.CSSProperties => {
    let bg = '#64748b';
    if (s === 'Reviewed') bg = '#3b82f6';
    if (s === 'Finalized') bg = '#10b981';
    
    return {
      backgroundColor: bg,
      color: 'white',
      padding: '4px 10px',
      borderRadius: '12px',
      fontSize: '0.8rem',
      fontWeight: 500
    }
  }

  return (
    <div style={containerStyle}>
      <h2 style={headerStyle}>Case Register</h2>

      <div style={filterBarStyle}>
        <input
          placeholder="Search ID or Customer Ref..."
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
          style={inputStyle}
        />
        <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} style={selectStyle}>
          <option value="">All Statuses</option>
          <option value="Draft">Draft</option>
          <option value="Reviewed">Reviewed</option>
          <option value="Finalized">Finalized</option>
        </select>
        <select value={priorityFilter} onChange={e => setPriorityFilter(e.target.value)} style={selectStyle}>
          <option value="">All Priorities</option>
          <option value="High">High</option>
          <option value="Medium">Medium</option>
          <option value="Low">Low</option>
        </select>
        <select value={channelFilter} onChange={e => setChannelFilter(e.target.value)} style={selectStyle}>
          <option value="">All Channels</option>
          <option value="Call">Call</option>
          <option value="Email">Email</option>
          <option value="Branch">Branch</option>
          <option value="Chat">Chat</option>
        </select>
        <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', fontWeight: 500, color: '#475569', marginLeft: 'auto' }}>
          <input
            type="checkbox"
            checked={slaBreachOnly}
            onChange={e => setSlaBreachOnly(e.target.checked)}
            style={{ width: '16px', height: '16px' }}
          />
          Show SLA Breach Only
        </label>
      </div>

      <div style={tableContainerStyle}>
        <table style={tableStyle}>
          <thead>
            <tr>
              <th style={thStyle}>Case ID</th>
              <th style={thStyle}>Customer Id</th>
              <th style={thStyle}>Type</th>
              <th style={thStyle}>Channel</th>
              <th style={thStyle}>Priority</th>
              <th style={thStyle}>Status</th>
              <th style={thStyle}>SLA Date</th>
              <th style={thStyle}>Created</th>
              <th style={thStyle}>Action</th>
            </tr>
          </thead>
          <tbody>
            {filteredCases.map(c => {
              const slaDate = getSlaDate(c)
              const breached = isBreached(c)
              return (
                <tr key={c.id} style={{ backgroundColor: breached ? '#fff1f2' : 'white', transition: 'background-color 0.2s' }}>
                  <td style={tdStyle}>{c.id}</td>
                  <td style={tdStyle}>{c.customerRef}</td>
                  <td style={tdStyle}>{c.type}</td>
                  <td style={tdStyle}>{c.channel}</td>
                  <td style={tdStyle}>
                    <span style={{ color: getPriorityColor(c.priority), fontWeight: 'bold' }}>{c.priority}</span>
                  </td>
                  <td style={tdStyle}>
                    <span style={getStatusBadgeStyle(c.status)}>{c.status}</span>
                  </td>
                  <td style={{ ...tdStyle, color: breached ? '#ef4444' : 'inherit', fontWeight: breached ? 'bold' : 'normal' }}>
                    {slaDate.toLocaleDateString()} {slaDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </td>
                  <td style={tdStyle}>{new Date(c.createdAt).toLocaleDateString()}</td>
                  <td style={tdStyle}>
                    <Link to={'/audit/' + c.id} style={{ color: '#3b82f6', textDecoration: 'none', fontWeight: 600, marginRight: '15px' }}>View</Link>
                    <Link to={'/edit/' + c.id} style={{ color: '#64748b', textDecoration: 'none', fontWeight: 600 }}>Edit</Link>
                  </td>
                </tr>
              )
            })}
            {filteredCases.length === 0 && (
              <tr>
                <td colSpan={9} style={{ ...tdStyle, textAlign: 'center', padding: '40px', color: '#94a3b8' }}>
                  No cases found matching your criteria.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}