import React from 'react'
import { render, screen } from '@testing-library/react'
import { Provider } from 'react-redux'
import { MemoryRouter, Routes, Route } from 'react-router-dom'
import AuditView from './AuditView'
import { store } from '../store/store'
import * as reactRedux from 'react-redux'

describe('AuditView Component', () => {
  const mockCase = { 
      id: '123', 
      customerRef: 'C1', 
      status: 'Draft', 
      priority: 'High', 
      channel: 'Call', 
      createdAt: new Date().toISOString(),
      aiNote: 'AI Note Content',
      finalNote: 'Final Note Content',
      rawNotes: 'Raw Notes Content',
      timeline: []
  }

  it('renders case details when found', () => {
    jest.spyOn(reactRedux, 'useSelector').mockReturnValue(mockCase)

    render(
      <Provider store={store}>
        <MemoryRouter initialEntries={['/audit/123']}>
            <Routes>
                <Route path="/audit/:id" element={<AuditView />} />
            </Routes>
        </MemoryRouter>
      </Provider>
    )

    expect(screen.getByText('Audit Log')).toBeInTheDocument()
    expect(screen.getByText(/Case ID: 123/)).toBeInTheDocument()
    expect(screen.getByText('AI Note Content')).toBeInTheDocument()
  })

  it('renders not found message when case is missing', () => {
    jest.spyOn(reactRedux, 'useSelector').mockReturnValue(undefined)

    render(
      <Provider store={store}>
        <MemoryRouter initialEntries={['/audit/999']}>
            <Routes>
                <Route path="/audit/:id" element={<AuditView />} />
            </Routes>
        </MemoryRouter>
      </Provider>
    )

    expect(screen.getByText('Case Not Found')).toBeInTheDocument()
  })
})