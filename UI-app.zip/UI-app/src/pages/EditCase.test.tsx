import React from 'react'
import { render, screen, fireEvent } from '@testing-library/react'
import { Provider } from 'react-redux'
import { MemoryRouter, Routes, Route } from 'react-router-dom'
import EditCase from './EditCase'
import { store } from '../store/store'
import * as reactRedux from 'react-redux'

// Mock useNavigate
const mockNavigate = jest.fn()
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockNavigate,
}))

describe('EditCase Component', () => {
  const mockCase = { 
      id: '123', 
      customerRef: 'C1', 
      status: 'Draft', 
      priority: 'High', 
      channel: 'Call', 
      rawNotes: 'Old Notes',
      timeline: []
  }

  beforeEach(() => {
      jest.clearAllMocks()
  })

  it('renders edit form with existing data', () => {
    jest.spyOn(reactRedux, 'useSelector').mockReturnValue(mockCase)

    render(
      <Provider store={store}>
        <MemoryRouter initialEntries={['/edit/123']}>
            <Routes>
                <Route path="/edit/:id" element={<EditCase />} />
            </Routes>
        </MemoryRouter>
      </Provider>
    )

    expect(screen.getByText('Edit Case')).toBeInTheDocument()
    expect(screen.getByDisplayValue('Old Notes')).toBeInTheDocument()
  })

  it('updates case on save', () => {
    jest.spyOn(reactRedux, 'useSelector').mockReturnValue(mockCase)
    const useDispatchSpy = jest.spyOn(reactRedux, 'useDispatch')
    const mockDispatch = jest.fn()
    useDispatchSpy.mockReturnValue(mockDispatch)

    render(
      <Provider store={store}>
        <MemoryRouter initialEntries={['/edit/123']}>
            <Routes>
                <Route path="/edit/:id" element={<EditCase />} />
            </Routes>
        </MemoryRouter>
      </Provider>
    )

    const notesInput = screen.getByDisplayValue('Old Notes')
    fireEvent.change(notesInput, { target: { value: 'New Notes' } })
    
    fireEvent.click(screen.getByText('Update Case'))

    expect(mockDispatch).toHaveBeenCalled()
    expect(mockNavigate).toHaveBeenCalledWith('/register')
  })
})