import React from 'react'
import { render, screen, fireEvent } from '@testing-library/react'
import { Provider } from 'react-redux'
import { MemoryRouter } from 'react-router-dom'
import CaseRegister from './CaseRegister'
import { store } from '../store/store'
import * as reactRedux from 'react-redux'

describe('CaseRegister Component', () => {
  const mockCases = [
    { id: '1', customerRef: 'C1', status: 'Draft', priority: 'High', channel: 'Call', createdAt: new Date().toISOString(), slaDate: new Date().toISOString() },
    { id: '2', customerRef: 'C2', status: 'Finalized', priority: 'Low', channel: 'Email', createdAt: new Date().toISOString(), slaDate: new Date().toISOString() },
  ]

  beforeEach(() => {
    jest.spyOn(reactRedux, 'useSelector').mockReturnValue(mockCases)
  })

  it('renders table with cases', () => {
    render(
      <Provider store={store}>
        <MemoryRouter>
          <CaseRegister />
        </MemoryRouter>
      </Provider>
    )

    expect(screen.getByText('C1')).toBeInTheDocument()
    expect(screen.getByText('C2')).toBeInTheDocument()
  })

  it('filters cases by search term', () => {
    render(
      <Provider store={store}>
        <MemoryRouter>
          <CaseRegister />
        </MemoryRouter>
      </Provider>
    )

    const searchInput = screen.getByPlaceholderText('Search ID or Customer Ref...')
    fireEvent.change(searchInput, { target: { value: 'C1' } })

    expect(screen.getByText('C1')).toBeInTheDocument()
    expect(screen.queryByText('C2')).not.toBeInTheDocument()
  })

  it('displays no cases found message', () => {
    jest.spyOn(reactRedux, 'useSelector').mockReturnValue([])
    render(<Provider store={store}><MemoryRouter><CaseRegister /></MemoryRouter></Provider>)
    expect(screen.getByText('No cases found matching your criteria.')).toBeInTheDocument()
  })
})