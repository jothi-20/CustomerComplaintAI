import { useParams, useNavigate } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { RootState } from '../store/store'

export default function AuditView() {
  const { id } = useParams()
  const nav = useNavigate()
  const c = useSelector((s: RootState) => s.cases.find(x => x.id === id))

  if (!c) return <div style={{ padding: 20 }}>Case Not Found</div>

  const stages = ['Draft', 'Reviewed', 'Finalized']
  const currentStageIndex = stages.indexOf(c.status) >= 0 ? stages.indexOf(c.status) : 0

  const handlePrint = () => {
    window.print()
  }

  // Use stored timeline or fallback for legacy data
  const timeline = c.timeline || [
    { time: new Date(c.createdAt).toLocaleString(), title: 'Case Created', detail: `Created via ${c.channel} | Priority: ${c.priority}` },
    { time: new Date(c.createdAt).toLocaleString(), title: 'AI Processing', detail: 'AI generated initial summary and notes' },
    ...(c.status !== 'Draft' ? [{ time: 'Recently', title: 'Status Update', detail: `Case moved to ${c.status}` }] : [])
  ]

  return (
    <div className="audit-container" style={{ padding: '40px', maxWidth: '1000px', margin: '0 auto', fontFamily: "'Segoe UI', sans-serif", color: '#333' }}>
      <style>
        {`
          @media print {
            .no-print { display: none !important; }
            body { background-color: white !important; }
            .audit-container { width: 100% !important; max-width: none !important; padding: 0 !important; margin: 0 !important; }
          }
        `}
      </style>

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '40px', borderBottom: '2px solid #eee', paddingBottom: '20px' }}>
        <div>
          <h1 style={{ margin: 0, fontSize: '2rem', color: '#004085' }}>Audit Log</h1>
          <p style={{ margin: '5px 0 0 0', color: '#666' }}>Case ID: {c.id} | Ref: {c.customerRef}</p>
        </div>
        <div className="no-print" style={{ display: 'flex', gap: '10px' }}>
          <button onClick={() => nav(-1)} style={{ padding: '10px 20px', border: '1px solid #ccc', background: 'white', borderRadius: '5px', cursor: 'pointer' }}>Back</button>
          <button onClick={handlePrint} style={{ padding: '10px 20px', background: '#0056b3', color: 'white', border: 'none', borderRadius: '5px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"></path></svg>
            Download PDF
          </button>
        </div>
      </div>

      {/* Progress Bar */}
      <div style={{ marginBottom: '50px' }}>
        <h3 style={{ marginBottom: '20px', color: '#444' }}>Case Progress</h3>
        <div style={{ display: 'flex', justifyContent: 'space-between', position: 'relative', maxWidth: '600px', margin: '0 auto' }}>
          {/* Line background */}
          <div style={{ position: 'absolute', top: '15px', left: '0', right: '0', height: '4px', background: '#e0e0e0', zIndex: 0 }}></div>
          
          {stages.map((stage, idx) => {
            const isActive = idx <= currentStageIndex
            return (
              <div key={stage} style={{ position: 'relative', zIndex: 1, textAlign: 'center' }}>
                <div style={{ 
                  width: '34px', height: '34px', borderRadius: '50%', 
                  background: isActive ? '#0056b3' : '#e0e0e0', 
                  color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center',
                  margin: '0 auto 10px auto', fontWeight: 'bold', transition: 'background 0.3s'
                }}>
                  {idx + 1}
                </div>
                <span style={{ color: isActive ? '#0056b3' : '#999', fontWeight: isActive ? 'bold' : 'normal' }}>{stage}</span>
              </div>
            )
          })}
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '40px' }}>
        {/* Left Column: Notes */}
        <div>
          <div style={{ marginBottom: '30px' }}>
            <h3 style={{ borderLeft: '4px solid #0056b3', paddingLeft: '10px', marginBottom: '15px' }}>AI Generated Note</h3>
            <div style={{ background: '#f8f9fa', padding: '20px', borderRadius: '8px', border: '1px solid #e9ecef', whiteSpace: 'pre-wrap', lineHeight: '1.6' }}>
              {c.aiNote}
            </div>
          </div>

          <div style={{ marginBottom: '30px' }}>
            <h3 style={{ borderLeft: '4px solid #28a745', paddingLeft: '10px', marginBottom: '15px' }}>Final Case Note</h3>
            <div style={{ background: '#fff', padding: '20px', borderRadius: '8px', border: '1px solid #ddd', boxShadow: '0 2px 4px rgba(0,0,0,0.05)', whiteSpace: 'pre-wrap', lineHeight: '1.6' }}>
              {c.finalNote}
            </div>
          </div>
          
          <div style={{ marginBottom: '30px' }}>
             <h3 style={{ borderLeft: '4px solid #6c757d', paddingLeft: '10px', marginBottom: '15px' }}>Raw Data</h3>
             <div style={{ background: '#f8f9fa', padding: '15px', borderRadius: '8px', fontSize: '0.9rem', color: '#666' }}>
               {c.rawNotes}
             </div>
          </div>
        </div>

        {/* Right Column: Timeline & Info */}
        <div>
          <div style={{ background: 'white', padding: '20px', borderRadius: '8px', border: '1px solid #eee', marginBottom: '30px', boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }}>
            <h3 style={{ marginTop: 0, marginBottom: '20px', color: '#333' }}>Ticket Flow</h3>
            <div style={{ position: 'relative', paddingLeft: '20px', borderLeft: '2px solid #e0e0e0' }}>
              {timeline.map((event, i) => (
                <div key={i} style={{ marginBottom: '25px', position: 'relative' }}>
                  <div style={{ position: 'absolute', left: '-26px', top: '0', width: '10px', height: '10px', borderRadius: '50%', background: '#0056b3', border: '2px solid white' }}></div>
                  <div style={{ fontSize: '0.85rem', color: '#888', marginBottom: '4px' }}>{event.time}</div>
                  <div style={{ fontWeight: 'bold', marginBottom: '4px', color: '#333' }}>{event.title}</div>
                  <div style={{ fontSize: '0.9rem', color: '#555' }}>{event.detail}</div>
                </div>
              ))}
            </div>
          </div>

          <div style={{ background: '#f1f5f9', padding: '20px', borderRadius: '8px' }}>
            <h4 style={{ margin: '0 0 15px 0', color: '#475569' }}>Case Details</h4>
            <div style={{ marginBottom: '10px' }}><strong>Type:</strong> {c.type}</div>
            <div style={{ marginBottom: '10px' }}><strong>Channel:</strong> {c.channel}</div>
            <div style={{ marginBottom: '10px' }}><strong>Priority:</strong> <span style={{ color: c.priority === 'High' ? 'red' : 'inherit' }}>{c.priority}</span></div>
          </div>
        </div>
      </div>
    </div>
  )
}