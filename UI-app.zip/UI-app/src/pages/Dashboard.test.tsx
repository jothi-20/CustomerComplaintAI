import React from 'react'
import { render, screen } from '@testing-library/react'
import { Provider } from 'react-redux'
import { MemoryRouter } from 'react-router-dom'
import Dashboard from './Dashboard'
import { store } from '../store/store'

describe('Dashboard Component', () => {
  const mockCases = [
    { id: '1', customerRef: 'Cust1', status: 'Draft', priority: 'High', channel: 'Call', customerSentiment: 'Positive', aiGeneratedTags: ['tag1', 'tag2'] },
    { id: '2', customerRef: 'Cust2', status: 'Reviewed', priority: 'Medium', channel: 'Email', customerSentiment: 'Negative', aiGeneratedTags: ['tag3'] },
  ]

  beforeEach(() => {
    // Mock the useSelector hook to return our mock cases
    jest.spyOn(require('react-redux'), 'useSelector').mockReturnValue(mockCases)
  })

  afterEach(() => {
    jest.restoreAllMocks()
  })

  it('renders the dashboard with recent cases', () => {
    render(
      <Provider store={store}>
        <MemoryRouter>
          <Dashboard />
        </MemoryRouter>
      </Provider>
    )

    // Check for the "Recent Cases" heading
    expect(screen.getByText('Recent Cases (Drill-down)')).toBeInTheDocument()

    // Check if the mock cases are rendered
    expect(screen.getByText('Cust1')).toBeInTheDocument()
    expect(screen.getByText('Cust2')).toBeInTheDocument()
  })

  it('displays "No cases found" when there are no cases', () => {
    // Mock useSelector to return an empty array
    jest.spyOn(require('react-redux'), 'useSelector').mockReturnValue([])

    render(
      <Provider store={store}>
        <MemoryRouter>
          <Dashboard />
        </MemoryRouter>
      </Provider>
    )

    expect(screen.getByText('No cases found')).toBeInTheDocument()
  })

  it('renders the card components with correct data', () => {
        render(
            <Provider store={store}>
                <MemoryRouter>
                    <Dashboard />
                </MemoryRouter>
            </Provider>
        );

        expect(screen.getByText('Total Cases')).toBeInTheDocument();
        expect(screen.getByText(mockCases.length.toString())).toBeInTheDocument();
    });
})