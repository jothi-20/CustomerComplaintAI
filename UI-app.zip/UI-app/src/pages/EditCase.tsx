import React, { useState, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { updateCase } from '../store/casesSlice'
import { useNavigate, useParams } from 'react-router-dom'
import { RootState } from '../store/store'

export default function EditCase() {
  const dispatch = useDispatch()
  const nav = useNavigate()
  const { id } = useParams()
  const existingCase = useSelector((state: RootState) => state.cases.find(c => c.id === id))

  const [status, setStatus] = useState('Draft')
  const [updateDate, setUpdateDate] = useState('')
  const [rawNotes, setRawNotes] = useState('')
  const [error, setError] = useState('')

  useEffect(() => {
    if (existingCase) {
      setStatus(existingCase.status)
      setRawNotes(existingCase.rawNotes)
      // Set default update date to now
      setUpdateDate(new Date().toISOString().slice(0, 16))
    }
  }, [existingCase])

  const save = () => {
    if (!rawNotes.trim()) {
      setError('Please add notes.')
      return
    }

    if (existingCase) {
      const newEvent = {
        time: new Date().toLocaleString(),
        title: 'Case Updated',
        detail: `Status: ${status} | Notes added`
      }

      dispatch(updateCase({
        ...existingCase,
        status,
        rawNotes,
        updatedAt: updateDate,
        timeline: [...(existingCase.timeline || []), newEvent]
      }))
      nav('/register')
    }
  }

  // Styles
  const containerStyle: React.CSSProperties = {
    maxWidth: '800px',
    margin: '40px auto',
    padding: '40px',
    backgroundColor: '#ffffff',
    borderRadius: '12px',
    boxShadow: '0 10px 25px rgba(0,0,0,0.05)',
    fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"
  };

  const headerStyle: React.CSSProperties = {
    backgroundColor: '#0056b3',
    color: 'white',
    padding: '25px 40px',
    margin: '-40px -40px 30px -40px',
    borderTopLeftRadius: '12px',
    borderTopRightRadius: '12px',
    fontSize: '1.5rem',
    fontWeight: 'bold',
    marginBottom: '30px',
  };

  const rowStyle: React.CSSProperties = {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: '20px',
    marginBottom: '20px'
  };

  const labelStyle: React.CSSProperties = {
    display: 'block',
    marginBottom: '8px',
    fontWeight: 600,
    color: '#4a5568',
    fontSize: '0.95rem'
  };

  const inputStyle: React.CSSProperties = {
    width: '100%',
    padding: '12px',
    borderRadius: '8px',
    border: '1px solid #e2e8f0',
    fontSize: '1rem',
    transition: 'border-color 0.2s',
    boxSizing: 'border-box'
  };

  const buttonContainerStyle: React.CSSProperties = {
    display: 'flex',
    justifyContent: 'flex-end',
    gap: '15px',
    marginTop: '30px'
  };

  const primaryButtonStyle: React.CSSProperties = {
    padding: '12px 24px',
    backgroundColor: '#0056b3',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    fontSize: '1rem',
    fontWeight: 600,
    cursor: 'pointer',
    boxShadow: '0 2px 4px rgba(0, 86, 179, 0.2)'
  };

  const secondaryButtonStyle: React.CSSProperties = {
    padding: '12px 24px',
    backgroundColor: '#edf2f7',
    color: '#4a5568',
    border: 'none',
    borderRadius: '6px',
    fontSize: '1rem',
    fontWeight: 600,
    cursor: 'pointer'
  };

  if (!existingCase) {
    return <div style={{ padding: 20 }}>Case not found</div>
  }

  return (
    <div style={{ backgroundColor: '#f8fafc', minHeight: '100vh', padding: '20px' }}>
      <div style={containerStyle}>
        <h2 style={headerStyle}>Edit Case</h2>
        {error && <div style={{ color: '#721c24', backgroundColor: '#f8d7da', padding: '10px', borderRadius: '5px', marginBottom: '20px', border: '1px solid #f5c6cb' }}>{error}</div>}
        
        {/* Read-only Case Details */}
        <div style={{ marginBottom: '30px', padding: '20px', backgroundColor: '#f1f5f9', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', fontSize: '0.95rem', color: '#2d3748' }}>
            <div><strong>Case ID:</strong> {existingCase.id}</div>
            <div><strong>Customer Ref:</strong> {existingCase.customerRef}</div>
            <div><strong>Type:</strong> {existingCase.type}</div>
            <div><strong>Channel:</strong> {existingCase.channel}</div>
            <div><strong>Priority:</strong> {existingCase.priority}</div>
          </div>
        </div>

        <div style={rowStyle}>
          <div>
            <label style={labelStyle}>Status</label>
            <select value={status} onChange={e => setStatus(e.target.value)} style={inputStyle}>
              <option value="Draft">Draft</option>
              <option value="Reviewed">Reviewed</option>
              <option value="Finalized">Finalized</option>
            </select>
          </div>
          <div>
            <label style={labelStyle}>Date of Update</label>
            <input type="datetime-local" value={updateDate} onChange={e => setUpdateDate(e.target.value)} style={inputStyle} />
          </div>
        </div>

        <div style={{ marginBottom: '20px' }}>
          <label style={labelStyle}>Notes</label>
          <textarea 
            rows={8} 
            value={rawNotes} 
            onChange={e => setRawNotes(e.target.value)} 
            style={{ ...inputStyle, resize: 'vertical', minHeight: '120px' }} 
            placeholder="Enter detailed case notes here..." 
          />
        </div>

        <div style={buttonContainerStyle}>
          <button onClick={() => nav('/register')} style={secondaryButtonStyle}>Cancel</button>
          <button onClick={save} style={primaryButtonStyle}>Update Case</button>
        </div>
      </div>
    </div>
  )
}