from sqlalchemy import Column, Integer, String, DateTime, JSON
from database import Base
from datetime import datetime

class Complaint(Base):
    __tablename__ = "complaints"

    id = Column(Integer, primary_key=True, index=True)
    customer_ref = Column(String, index=True)
    type = Column(String)
    channel = Column(String, default="Call")
    priority = Column(String)
    raw_notes = Column(String)
    ai_note = Column(String)
    final_note = Column(String)
    status = Column(String, default="Draft")
    created_at = Column(DateTime, default=datetime.utcnow)
    sla_date = Column(DateTime)
    timeline = Column(JSON)
    customer_sentiment = Column(String)
    ai_generated_tags = Column(JSON)
    relevant_department = Column(String)
    history_analysis = Column(String)