from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from fastapi.middleware.cors import CORSMiddleware
from datetime import datetime, timedelta
import os
import httpx
from dotenv import load_dotenv
import models, schemas, database
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import JsonOutputParser

models.Base.metadata.create_all(bind=database.engine)
load_dotenv()

# Workaround for incorrect SSL_CERT_FILE environment variable causing FileNotFoundError
os.environ.pop("SSL_CERT_FILE", None)

# Global client to reuse connections (Significant performance improvement)
http_client = httpx.Client(verify=False, trust_env=False, timeout=60.0)

app = FastAPI()

# Enable CORS for your React frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def get_db():
    db = database.SessionLocal()
    try:
        yield db
    finally:
        db.close()

def analyze_complaint(channel, interaction_type, priority, raw_notes, history_text, customer_id):
    llm = ChatOpenAI(
        temperature=0,
        base_url=os.getenv("OPENAI_API_BASE"),
        model=os.getenv("OPENAI_API_MODEL"),
        api_key=os.getenv("OPENAI_API_KEY"),
        http_client=http_client
    )

    prompt = ChatPromptTemplate.from_template(
        "You are a professional Banking Support Agent. Your task is to process customer inquiries with strict adherence to banking relevance.\n\n"
        "1. VALIDATION STEP: Check if the 'Raw Notes' are relevant to banking, finance, or customer account support. "
        "If the input is unrelated (e.g., 'meaning of life', coding questions, recipes, sports) or gibberish, mark 'is_valid' as false.\n"
        "2. ANALYSIS STEP: If valid, analyze the interaction context and history. "
        "STRICTLY use only the provided information. Do not hallucinate or invent details. Keep the summary concise.\n\n"
        "Context:\n"
        "Customer ID: {customer_id}\n"
        "Channel: {channel}\n"
        "Type: {interaction_type}\n"
        "Priority: {priority}\n"
        "Raw Notes: {raw_notes}\n"
        "Customer History: {history_text}\n\n"
        "Provide the output in JSON format with the following keys:\n"
        "- is_valid: boolean (true if banking related, false otherwise)\n"
        "- validation_reason: string (reason for rejection if invalid, else null)\n"
        "- summary: A professional summary including Action Taken and Next Steps.\n"
        "- customer_sentiment: The sentiment of the customer (e.g., Angry, Neutral, Happy).\n"
        "- tags: A list of relevant tags (e.g., ['Credit Card', 'Dispute']).\n"
        "- relevant_department: The department best suited to handle this (e.g., Fraud, Support).\n"
        "- history_analysis: A brief analysis of the customer's history and how it relates to this case."
    )
    chain = prompt | llm | JsonOutputParser()
    return chain.invoke({"channel": channel, "interaction_type": interaction_type, "priority": priority, "raw_notes": raw_notes, "history_text": history_text, "customer_id": customer_id})

def generate_suggestions(channel, interaction_type, priority, raw_notes, history_text, customer_id):
    llm = ChatOpenAI(
        temperature=0,
        max_tokens=500, # Limit output tokens to speed up generation
        base_url=os.getenv("OPENAI_API_BASE"),
        model=os.getenv("OPENAI_API_MODEL"),
        api_key=os.getenv("OPENAI_API_KEY"),
        http_client=http_client
    )

    prompt = ChatPromptTemplate.from_template(
        "You are a professional Banking Support Agent assisting a customer.\n"
        "Your goal is to provide realistic, empathetic, and professional auto-suggestions for the agent to use.\n\n"
        "1. VALIDATION: Analyze the 'Raw Notes'. If they are unrelated to banking/finance (e.g., 'how to cook pasta', 'sports scores') or gibberish, set 'is_valid' to false.\n"
        "2. SUGGESTION: If valid, generate a 'suggested_response' that the agent can say to the customer, and 'suggested_actions' for the agent to perform.\n"
        "Keep suggestions concise, exact, and strictly relevant to the provided notes. Do not make up policies or external facts.\n\n"
        "Context:\n"
        "Customer ID: {customer_id}\n"
        "Channel: {channel}\n"
        "Type: {interaction_type}\n"
        "Priority: {priority}\n"
        "Raw Notes: {raw_notes}\n"
        "Customer History Summary: {history_text}\n\n"
        "Output JSON format:\n"
        "{{\n"
        "  \"is_valid\": boolean,\n"
        "  \"validation_reason\": string or null,\n"
        "  \"suggested_response\": string (script for the agent),\n"
        "  \"suggested_actions\": [string] (list of steps)\n"
        "}}"
    )
    chain = prompt | llm | JsonOutputParser()
    return chain.invoke({
        "channel": channel, 
        "interaction_type": interaction_type, 
        "priority": priority, 
        "raw_notes": raw_notes, 
        "history_text": history_text, 
        "customer_id": customer_id
    })

def get_sla_hours(priority):
    if priority == 'High': return 24
    if priority == 'Medium': return 48
    return 72

@app.post("/complaints/", response_model=schemas.ComplaintResponse)
def create_complaint(complaint: schemas.ComplaintCreate, db: Session = Depends(get_db)):
    channel = "Call" # Defaulting to Call as it wasn't in the specific input payload
    
    # Fetch History
    history = db.query(models.Complaint).filter(models.Complaint.customer_ref == complaint.customer_id).all()
    history_text = "No prior history."
    if history:
        history_text = "\n".join([f"- {h.created_at.date()}: {h.type} ({h.priority})" for h in history])

    # Generate derived data
    analysis = analyze_complaint(channel, complaint.interaction_type, complaint.priority, complaint.notes, history_text, complaint.customer_id)
    
    if analysis.get("is_valid") is False:
        raise HTTPException(status_code=400, detail=analysis.get("validation_reason", "Input is not relevant to banking operations."))
    
    summary_data = analysis.get("summary", "Summary unavailable")
    if isinstance(summary_data, dict):
        final_note = "\n".join([f"{k}: {v}" for k, v in summary_data.items()])
    else:
        final_note = str(summary_data)
    
    sla_hours = get_sla_hours(complaint.priority)
    created_at = datetime.utcnow()
    sla_date = created_at + timedelta(hours=sla_hours)
    
    timeline = [
        {
            "time": created_at.isoformat(), 
            "title": "Case Created", 
            "detail": f"Created via {channel} | Priority: {complaint.priority}"
        },
        {
            "time": created_at.isoformat(), 
            "title": "AI Processing", 
            "detail": "AI generated initial summary and notes"
        }
    ]

    db_complaint = models.Complaint(
        customer_ref=complaint.customer_id,
        type=complaint.interaction_type,
        channel=channel,
        priority=complaint.priority,
        raw_notes=complaint.notes,
        ai_note=final_note,
        final_note=final_note,
        status="Draft",
        created_at=created_at,
        sla_date=sla_date,
        timeline=timeline,
        customer_sentiment=analysis.get("customer_sentiment"),
        ai_generated_tags=analysis.get("tags"),
        relevant_department=analysis.get("relevant_department"),
        history_analysis=analysis.get("history_analysis")
    )
    
    db.add(db_complaint)
    db.commit()
    db.refresh(db_complaint)
    return db_complaint

@app.post("/suggestions", response_model=schemas.SuggestionResponse)
def get_complaint_suggestions(complaint: schemas.ComplaintCreate, db: Session = Depends(get_db)):
    channel = "Call"
    
    # Fetch History for context
    history = db.query(models.Complaint).filter(models.Complaint.customer_ref == complaint.customer_id).all()
    history_text = "No prior history."
    if history:
        history_text = "\n".join([f"- {h.created_at.date()}: {h.type} ({h.priority})" for h in history])

    result = generate_suggestions(
        channel, 
        complaint.interaction_type, 
        complaint.priority, 
        complaint.notes, 
        history_text, 
        complaint.customer_id
    )
    
    if result.get("is_valid") is False:
        raise HTTPException(status_code=400, detail=result.get("validation_reason", "Input is not relevant to banking operations."))
        
    return result