import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from main import app, get_db
import models
from unittest.mock import patch

# Setup in-memory SQLite database for testing
# StaticPool is used to maintain the same in-memory database across multiple threads
SQLALCHEMY_DATABASE_URL = "sqlite:///:memory:"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

models.Base.metadata.create_all(bind=engine)

def override_get_db():
    try:
        db = TestingSessionLocal()
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db] = override_get_db

client = TestClient(app)

# --- Mock Data ---

MOCK_VALID_ANALYSIS = {
    "is_valid": True,
    "validation_reason": None,
    "summary": {
        "Action Taken": "Logged complaint",
        "Next Steps": "Investigate transaction"
    },
    "customer_sentiment": "Angry",
    "tags": ["Fraud", "Credit Card"],
    "relevant_department": "Fraud Dept",
    "history_analysis": "First time caller"
}

MOCK_INVALID_ANALYSIS = {
    "is_valid": False,
    "validation_reason": "Input is about cooking, not banking.",
    "summary": {},
    "customer_sentiment": None,
    "tags": [],
    "relevant_department": None,
    "history_analysis": None
}

MOCK_VALID_SUGGESTION = {
    "is_valid": True,
    "validation_reason": None,
    "suggested_response": "I can help you with that transaction.",
    "suggested_actions": ["Verify identity", "Check transaction logs"]
}

# --- Tests ---

def test_create_complaint_success():
    with patch("main.analyze_complaint") as mock_analyze:
        mock_analyze.return_value = MOCK_VALID_ANALYSIS
        
        payload = {
            "customer-id": "CUST-001",
            "Priority": "High",
            "Interaction Type": "Complaint",
            "Notes": "I see a fraudulent transaction on my card."
        }
        
        response = client.post("/complaints/", json=payload)
        
        assert response.status_code == 200
        data = response.json()
        assert data["customer_ref"] == "CUST-001"
        assert data["priority"] == "High"
        assert data["customer_sentiment"] == "Angry"
        # Verify dictionary summary was converted to string in final_note
        assert "Logged complaint" in data["final_note"]
        assert data["ai_generated_tags"] == ["Fraud", "Credit Card"]

def test_create_complaint_invalid_input():
    with patch("main.analyze_complaint") as mock_analyze:
        mock_analyze.return_value = MOCK_INVALID_ANALYSIS
        
        payload = {
            "customer-id": "CUST-002",
            "Priority": "Low",
            "Interaction Type": "Inquiry",
            "Notes": "How do I bake a cake?"
        }
        
        response = client.post("/complaints/", json=payload)
        
        assert response.status_code == 400
        assert response.json()["detail"] == "Input is about cooking, not banking."

def test_get_suggestions_success():
    with patch("main.generate_suggestions") as mock_suggest:
        mock_suggest.return_value = MOCK_VALID_SUGGESTION
        
        payload = {
            "customer-id": "CUST-001",
            "Priority": "Medium",
            "Interaction Type": "Inquiry",
            "Notes": "My card is declined."
        }
        
        response = client.post("/suggestions", json=payload)
        
        assert response.status_code == 200
        data = response.json()
        assert data["is_valid"] is True
        assert data["suggested_response"] == "I can help you with that transaction."
        assert len(data["suggested_actions"]) == 2

def test_database_persistence():
    # Ensure that data is actually saved to the test database
    with patch("main.analyze_complaint") as mock_analyze:
        mock_analyze.return_value = MOCK_VALID_ANALYSIS
        
        payload = {
            "customer-id": "PERSIST-TEST",
            "Priority": "Medium",
            "Interaction Type": "Complaint",
            "Notes": "Testing persistence."
        }
        
        client.post("/complaints/", json=payload)
        
        # Direct DB check
        db = TestingSessionLocal()
        complaint = db.query(models.Complaint).filter(models.Complaint.customer_ref == "PERSIST-TEST").first()
        assert complaint is not None
        assert complaint.priority == "Medium"
        db.close()