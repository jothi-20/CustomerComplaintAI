from pydantic import BaseModel, Field
from typing import Optional, List, Any
from datetime import datetime

class ComplaintCreate(BaseModel):
    customer_id: str = Field(..., alias="customer-id")
    priority: str = Field(..., alias="Priority")
    interaction_type: str = Field(..., alias="Interaction Type")
    notes: str = Field(..., alias="Notes")

class ComplaintResponse(BaseModel):
    id: int
    customer_ref: str
    type: str
    channel: str
    priority: str
    raw_notes: str
    ai_note: str
    final_note: str
    status: str
    created_at: datetime
    sla_date: Optional[datetime]
    timeline: List[Any]
    customer_sentiment: Optional[str]
    ai_generated_tags: Optional[List[str]]
    relevant_department: Optional[str]
    history_analysis: Optional[str]

    class Config:
        orm_mode = True

class SuggestionResponse(BaseModel):
    is_valid: bool
    validation_reason: Optional[str] = None
    suggested_response: Optional[str] = None
    suggested_actions: Optional[List[str]] = None